/**
 * INPUT TAGAREA COMPONENT — JavaScript
 * Figma Source: Input_TagArea (node 5183:20602)
 *
 * Handles interactive behavior for the input tagarea component showcase:
 *   - Tab switching between tagarea style/type variants
 *   - Code snippet toggling (HTML / SCSS views)
 *   - Copy-to-clipboard for code blocks
 */

(function () {
    'use strict';

    /* -----------------------------------------------------------------------
       INPUT TAGAREA VARIANT CONFIGURATION
       Maps Figma variant properties to CSS class combinations
       (No -- in class names – uses single-hyphen modifiers)
       ----------------------------------------------------------------------- */
    var INPUT_TAGAREA_VARIANTS = {
        styles: [
            { key: 'empty',     label: 'Empty',     cls: '' },
            { key: 'with-tags', label: 'With Tags', cls: '' },
            { key: 'search',    label: 'Search',    cls: '' },
            { key: 'overflow',  label: 'Overflow',  cls: '' },
            { key: 'disabled',  label: 'Disabled',  cls: 'zc-tagarea-disabled' }
        ]
    };

    window.INPUT_TAGAREA_VARIANTS = INPUT_TAGAREA_VARIANTS;

    /* -----------------------------------------------------------------------
       SWITCH INPUT TAGAREA STYLE TAB
       ----------------------------------------------------------------------- */
    window.switchInputTagareaStyleTab = function (styleKey, tabEl) {
        var container = document.getElementById('input-tagarea-component-variants');
        if (!container) return;

        container.closest('.component-detail-view')
            .querySelectorAll('.btn-style-tab').forEach(function (t) {
                t.classList.remove('active');
            });
        if (tabEl) tabEl.classList.add('active');

        container.querySelectorAll('.btn-variant-group').forEach(function (group) {
            if (group.dataset.style === styleKey) {
                group.style.display = 'block';
                group.style.animation = 'fadeIn 0.3s ease';
            } else {
                group.style.display = 'none';
            }
        });
    };

    /* -----------------------------------------------------------------------
       COPY INPUT TAGAREA CODE
       ----------------------------------------------------------------------- */
    window.copyInputTagareaCode = function (btn) {
        var codeBlock = btn.closest('.btn-code-block').querySelector('code');
        if (!codeBlock) return;

        navigator.clipboard.writeText(codeBlock.textContent).then(function () {
            var icon = btn.querySelector('i');
            if (icon) {
                icon.className = 'fas fa-check';
                setTimeout(function () { icon.className = 'fas fa-copy'; }, 1500);
            }
        });
    };

    /* -----------------------------------------------------------------------
       TOGGLE CODE PANEL
       ----------------------------------------------------------------------- */
    window.toggleInputTagareaCodePanel = function (btn) {
        var card = btn.closest('.btn-variant-card');
        if (!card) return;
        var codePanel = card.querySelector('.btn-code-panel');
        if (!codePanel) return;

        var isVisible = codePanel.style.display === 'block';
        codePanel.style.display = isVisible ? 'none' : 'block';
        btn.classList.toggle('active', !isVisible);

        var span = btn.querySelector('span');
        if (span) span.textContent = isVisible ? 'Show Code' : 'Hide Code';
    };

    /* -----------------------------------------------------------------------
       SWITCH CODE TAB (HTML / SCSS)
       ----------------------------------------------------------------------- */
    window.switchInputTagareaCodeTab = function (tab, tabEl) {
        var panel = tabEl.closest('.btn-code-panel');
        if (!panel) return;

        panel.querySelectorAll('.btn-code-tab').forEach(function (t) {
            t.classList.remove('active');
        });
        tabEl.classList.add('active');

        panel.querySelectorAll('.btn-code-block').forEach(function (block) {
            block.style.display = block.dataset.lang === tab ? 'block' : 'none';
        });
    };

})();
